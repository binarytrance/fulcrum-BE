import { Application, NextFunction, Request, Response } from 'express';
import { injectable } from 'tsyringe';
import {
  ApiLoggerMiddleware,
  BodyParserMiddleware,
  CompressionMiddleware,
  GlobalErrorHandlerMiddleware,
  GlobalRateLimitMiddleware,
  GlobalResponseHandlerMiddleware,
  PassportMiddleware,
  SecurityMiddleware,
  SessionMiddleware,
} from '../app';
import { AuthMiddleware } from '../route';

@injectable()
export class MiddlewareFactory {
  constructor(
    private readonly apiLoggerMiddleware: ApiLoggerMiddleware,
    private readonly bodyparserMiddleware: BodyParserMiddleware,
    private readonly compressionMiddleware: CompressionMiddleware,
    private readonly globalErrorHandlerMiddleware: GlobalErrorHandlerMiddleware,
    private readonly globalResponseHandlerMiddleware: GlobalResponseHandlerMiddleware,
    private readonly gloablRateLimitMiddleware: GlobalRateLimitMiddleware,
    private readonly securityMiddleware: SecurityMiddleware,
    private readonly sessionMiddleware: SessionMiddleware,
    private readonly authMiddleware: AuthMiddleware,
    private readonly passportMiddleware: PassportMiddleware
  ) {}

  public registerApiLoggerMiddleware(app: Application) {
    this.apiLoggerMiddleware.register(app);
  }

  public registerBodyParserMiddleware(app: Application) {
    this.bodyparserMiddleware.register(app);
  }

  public registerCompressionMiddleware(app: Application) {
    this.compressionMiddleware.register(app);
  }

  public registerGlobalErrorHandlerMiddleware(app: Application) {
    this.globalErrorHandlerMiddleware.register(app);
  }

  public registerGlobalResponseHandlerMiddleware(app: Application) {
    this.globalResponseHandlerMiddleware.register(app);
  }

  public registerGlobalRateLimitMiddleware(app: Application) {
    this.gloablRateLimitMiddleware.register(app);
  }

  public registerSecurityMiddlewares(app: Application) {
    this.securityMiddleware.register(app);
  }

  public registerSessionMiddleware(app: Application) {
    this.sessionMiddleware.register(app);
  }

  public registerPassportMiddleware(app: Application) {
    this.passportMiddleware.register(app);
  }

  public checkAuthentication(req: Request, res: Response, next: NextFunction) {
    this.authMiddleware.handler(req, res, next);
  }
}
