// src/app/middleware/security.middleware.ts
import { injectable } from 'tsyringe';
import type { Application } from 'express';
import helmet from 'helmet';
import hpp from 'hpp';
import cors from 'cors';
import { AppMiddleware } from '../base';

@injectable()
export class SecurityMiddleware extends AppMiddleware {
  register(app: Application) {
    app.use(helmet());
    app.use(hpp());
    app.use(cors());
  }
}
