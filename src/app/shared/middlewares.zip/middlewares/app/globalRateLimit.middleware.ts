import { injectable } from 'tsyringe';
import { Application } from 'express';
import rateLimit, { Options } from 'express-rate-limit';
import { AppMiddleware } from '../base';

@injectable()
export class GlobalRateLimitMiddleware extends AppMiddleware {
  register(app: Application): void {
    const rateLimitingOptions: Partial<Options> = {
      windowMs: 15 * 60 * 1000,
      limit: 50000,
      standardHeaders: 'draft-8',
      legacyHeaders: false,
    };

    app.use(rateLimit(rateLimitingOptions));
  }
}
