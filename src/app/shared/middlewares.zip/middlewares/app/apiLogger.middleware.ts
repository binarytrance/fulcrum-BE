import { Application, Request, Response } from 'express';
import morgan, { Morgan, StreamOptions } from 'morgan';
import { DateTime } from 'luxon';
import { inject, injectable } from 'tsyringe';
import { AppMiddleware } from '../base';
import { Logger } from '~/app/shared/config';

@injectable()
export class ApiLoggerMiddleware extends AppMiddleware {
  constructor(private logger: Logger) {
    super();
  }

  register(app: Application): void {
    const stream: StreamOptions = {
      write: (message: string) => {
        const localTime = DateTime.local().toFormat('yyyy-LL-dd HH:mm:ss');
        this.logger.info(`[${localTime}] ${message.trim()}`);
      },
    };
    app.use(morgan('combined', { stream }));
  }
}
