import { injectable } from 'tsyringe';
import { Application } from 'express';
import compression, { CompressionOptions } from 'compression';
import { AppMiddleware } from '../base';

@injectable()
export class CompressionMiddleware extends AppMiddleware {
  register(app: Application): void {
    const compressionOptions: CompressionOptions = {
      level: 6,
      threshold: 1024,
    };

    app.use(compression(compressionOptions));
  }
}
