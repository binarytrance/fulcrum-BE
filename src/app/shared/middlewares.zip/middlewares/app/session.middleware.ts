import expressSession, { SessionOptions } from 'express-session';
import { RedisStore } from 'connect-redis';
import { Application } from 'express';
import { AppMiddleware } from '../base';
import { Redis } from '~/app/shared/services';
import { Env } from '~/app/shared/config';
import { injectable } from 'tsyringe';

@injectable()
export class SessionMiddleware extends AppMiddleware {
  constructor(private redis: Redis, private env: Env) {
    super();
  }

  public register(app: Application) {
    const store = new RedisStore({ client: this.redis.connection });
    const sessionOptions: SessionOptions = {
      store,
      secret: this.env.app.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: this.env.app.NODE_ENV === 'production',
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000,
      },
    };

    app.use(expressSession(sessionOptions));
  }
}
