import { inject, injectable } from 'tsyringe';
import { AppMiddleware } from '../base';
import { Application } from 'express';
import passport from 'passport';

@injectable()
export class PassportMiddleware extends AppMiddleware {
  register(app: Application): void {
    app.use(passport.initialize());
    app.use(passport.session());
  }
}
